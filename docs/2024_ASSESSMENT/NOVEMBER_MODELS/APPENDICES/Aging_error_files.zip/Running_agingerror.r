

## splined aging error
data<-AgeingError:::CreateData("dataBoth10.dat", NDataSet = 1, verbose = TRUE, EchoFile = "data_echo.out")
PCOD_spline <- AgeingError:::CreateSpecs("spline5.spc", DataSpecs = data,verbose = TRUE)

PCOD_spline <- AgeingError::DoApplyAgeError(
  Species = "Pcod",
  DataSpecs = data,
  ModelSpecsInp = PCOD_spline,
  AprobWght = 1e-06,
  SlopeWght = 0.01,
  SaveDir = "Results_spline",
  verbose = TRUE
)


PCOD_spline_out <- AgeingError:::ProcessResults(Species = "Pcod", SaveDir = "Results_spline", CalcEff = TRUE, verbose = FALSE)

## linear aging error
data<-AgeingError:::CreateData("dataBoth10.dat", NDataSet = 1, verbose = TRUE, EchoFile = "data_echo.out")
PCOD_linear <- AgeingError:::CreateSpecs("linear.spc", DataSpecs = data,verbose = TRUE)

PCOD_linear <- AgeingError::DoApplyAgeError(
  Species = "Pcod",
  DataSpecs = data,
  ModelSpecsInp = PCOD_linear,
  AprobWght = 1e-06,
  SlopeWght = 0.01,
  SaveDir = "Results_linear",
  verbose = TRUE
)


PCOD_linear_out <- AgeingError:::ProcessResults(Species = "Pcod", SaveDir = "Results_linear", CalcEff = TRUE, verbose = FALSE)


## splined aging error
data<-AgeingError:::CreateData("dataREREADS.dat", NDataSet = 1, verbose = TRUE, EchoFile = "data_echo.out")
PCOD_spline_bias <- AgeingError:::CreateSpecs("spline5_bias.spc", DataSpecs = data,verbose = TRUE)

PCOD_spline <- AgeingError::DoApplyAgeError(
  Species = "Pcod",
  DataSpecs = data,
  ModelSpecsInp = PCOD_spline_bias,
  AprobWght = 1e-06,
  SlopeWght = 0.01,
  SaveDir = "Results_spline_bias",
  verbose = TRUE
)


PCOD_spline_bias_out <- AgeingError:::ProcessResults(Species = "Pcod", SaveDir = "Results_spline_bias", CalcEff = TRUE, verbose = FALSE)
